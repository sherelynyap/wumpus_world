* File Name: "Agent.pl"
	* Team KJS Agent code 

### Folder: Driver
* File Name: "TeamKJS-testPrintout-Others.txt"
	* Presentation of the absolute map updates given a sequence of actions (2 actions) 
* File Name: "Driver.py"
	* MAIN = > Team KJS Driver code (The Agent code is to be placed at the directory before this)

* File Name: "map.py"
	* Map classes defined for the driver